#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	
	double n;
	cin>>n;
	printf("%f\n",n);
	printf("%.5f\n",n);
	printf("%e\n",n);
	printf("%g\n",n);
    return 0;
}