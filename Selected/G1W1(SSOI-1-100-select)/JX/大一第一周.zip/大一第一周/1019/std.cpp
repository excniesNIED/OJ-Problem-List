#include<iostream>
using namespace std;
int main()
{ 
	double n;
	cin>>n;
	cout<<int(n)<<endl;
  	return 0;
}