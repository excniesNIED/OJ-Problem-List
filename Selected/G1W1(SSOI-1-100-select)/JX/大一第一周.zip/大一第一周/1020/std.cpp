#include<iostream>
using namespace std;
int main()
{ 
	char ch;
	cin>>ch;
	cout<<int(ch)<<endl;
  	return 0;
}