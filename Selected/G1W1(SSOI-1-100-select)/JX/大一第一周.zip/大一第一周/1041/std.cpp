#include <iostream>
using namespace std;
int main()
{
	int N;
	cin>>N;
 	if(N%2) cout<<"odd"<<endl;
 	else cout<<"even"<<endl;
        return 0;
}