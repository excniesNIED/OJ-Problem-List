#include<iostream>
using namespace std;
int main()
{ 
	cout<<sizeof(int)<<" "<<sizeof(short)<<endl;
  	return 0;
}