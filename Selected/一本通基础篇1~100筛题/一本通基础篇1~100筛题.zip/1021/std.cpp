#include<iostream>
using namespace std;
int main()
{ 
	int n;
	cin>>n;
	cout<<char(n)<<endl;
  	return 0;
}