#include<iostream>
using namespace std;
int main()
{ 
	int n;
	cin>>n;
	cout<<bool(n)<<endl;
  	return 0;
}