#include<iostream>
using namespace std;
int main()
{ 
	cout<<sizeof(float)<<" "<<sizeof(double)<<endl;
  	return 0;
}