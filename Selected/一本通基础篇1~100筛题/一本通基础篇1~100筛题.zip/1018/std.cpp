#include<iostream>
using namespace std;
int main()
{ 
	cout<<sizeof(bool)<<" "<<sizeof(char)<<endl;
  	return 0;
}