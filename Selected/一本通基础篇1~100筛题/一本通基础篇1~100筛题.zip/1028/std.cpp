#include<iostream>
using namespace std;
int main()
{
	
	char ch;
	cin>>ch;
	cout<<"  "<<ch<<endl;
	cout<<" "<<ch<<ch<<ch<<endl;
	cout<<ch<<ch<<ch<<ch<<ch<<endl;
	cout<<" "<<ch<<ch<<ch<<endl;
	cout<<"  "<<ch<<endl;
	return 0;
}