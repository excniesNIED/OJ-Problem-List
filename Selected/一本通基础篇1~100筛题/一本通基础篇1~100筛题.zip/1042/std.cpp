#include <iostream> 
#include <cstdio>
using namespace std;  
int main()  
{  
    char ch;  
    scanf("%c",&ch);
    if (ch%2 == 0) cout << "NO" << endl;  
    else cout << "YES" << endl;  
    return 0;  
} 